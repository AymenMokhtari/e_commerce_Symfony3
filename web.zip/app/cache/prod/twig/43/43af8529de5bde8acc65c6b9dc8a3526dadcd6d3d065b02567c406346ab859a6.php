<?php

/* EcommerceEcommerceBundle:Default:aboutus.html.twig */
class __TwigTemplate_33d5d0d5648fdc58da9ed94299905a7616c6bb21bb618d2e69d9675b626f5c81 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("EcommerceEcommerceBundle::layout.html.twig", "EcommerceEcommerceBundle:Default:aboutus.html.twig", 3);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "EcommerceEcommerceBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        echo "    

    
        
        
<div class=\"path\">
          <a href=\"\">  <i class=\"fa fa-home home-logo\"></i> <span class=\"path-1\">Accueil</span></a><i class=\"fa fa-angle-double-right\"></i>
           <span class=\"path-1\"><a href=\"\">Qui sommes-nous ?</a></span>
          
       </div>
       
       
       <h2 class=\"page-title\">Qui Sommes-nous</h2>
       <div class=\"title-underline\">
           
           <hr>
           <div class=\"blue-underline\"></div>
       </div>
       
       
       <h2 class=\"para-title\">   Mieux nous connaitre</h2>
       <div class=\"para-left\">
        <p>Notre société nouvellement créée intervient dans le domaine de commercialisation de matériels électrique, travaux électricité industriel et bâtiment, éclairage intérieur et extérieur et réparation des armoires électriques mettant à votre disposition des produits hauts de gammes pour une installation électrique claire et sans défaut.</p>
        <p>
Tout notre savoir-faire en matière de dépannage et d’installation électrique est mis à votre disposition pour la construction ou la rénovation de bâtiments. Nous proposons nos prestations aux professionnels comme aux particuliers.</p>
   
   <h2 class=\"para-title\">PRESTATIONS</h2>
   
   <ul class=\"prestation\">
       <li>Dépannage d'installation électrique</li>
       <li>Rénovation d'installation électrique</li>
       <li>Mise en conformité d'installation électrique</li>
       <li>Installation de tableau électrique</li>
       <li>Installation de disjoncteur</li>
       <li> Installation d'armoire électrique</li>
       
   </ul>
    </div>
     
   
   
       <div style=\"clear:both;\"></div>
       
         ";
    }

    public function getTemplateName()
    {
        return "EcommerceEcommerceBundle:Default:aboutus.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 5,  28 => 4,  11 => 3,);
    }
}
/* */
/*   */
/* {%extends "EcommerceEcommerceBundle::layout.html.twig"%}*/
/* {% block content %}*/
/*     */
/* */
/*     */
/*         */
/*         */
/* <div class="path">*/
/*           <a href="">  <i class="fa fa-home home-logo"></i> <span class="path-1">Accueil</span></a><i class="fa fa-angle-double-right"></i>*/
/*            <span class="path-1"><a href="">Qui sommes-nous ?</a></span>*/
/*           */
/*        </div>*/
/*        */
/*        */
/*        <h2 class="page-title">Qui Sommes-nous</h2>*/
/*        <div class="title-underline">*/
/*            */
/*            <hr>*/
/*            <div class="blue-underline"></div>*/
/*        </div>*/
/*        */
/*        */
/*        <h2 class="para-title">   Mieux nous connaitre</h2>*/
/*        <div class="para-left">*/
/*         <p>Notre société nouvellement créée intervient dans le domaine de commercialisation de matériels électrique, travaux électricité industriel et bâtiment, éclairage intérieur et extérieur et réparation des armoires électriques mettant à votre disposition des produits hauts de gammes pour une installation électrique claire et sans défaut.</p>*/
/*         <p>*/
/* Tout notre savoir-faire en matière de dépannage et d’installation électrique est mis à votre disposition pour la construction ou la rénovation de bâtiments. Nous proposons nos prestations aux professionnels comme aux particuliers.</p>*/
/*    */
/*    <h2 class="para-title">PRESTATIONS</h2>*/
/*    */
/*    <ul class="prestation">*/
/*        <li>Dépannage d'installation électrique</li>*/
/*        <li>Rénovation d'installation électrique</li>*/
/*        <li>Mise en conformité d'installation électrique</li>*/
/*        <li>Installation de tableau électrique</li>*/
/*        <li>Installation de disjoncteur</li>*/
/*        <li> Installation d'armoire électrique</li>*/
/*        */
/*    </ul>*/
/*     </div>*/
/*      */
/*    */
/*    */
/*        <div style="clear:both;"></div>*/
/*        */
/*          {% endblock %}*/
