<?php

/* EcommerceEcommerceBundle:Default:index.html.twig */
class __TwigTemplate_e6185c436f9b59bbee269a6c2e6d1db9bdfb043cc60108e9635a00d90c3be805 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("EcommerceEcommerceBundle::layout.html.twig", "EcommerceEcommerceBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "EcommerceEcommerceBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "    
  
        
       <ul class=\"top-logos\">
           <li><img src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/Siemens-logo.png"), "html", null, true);
        echo "\" alt=\"\"></li>
           <li><img src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/shneider.png"), "html", null, true);
        echo "\" alt=\"\"></li>
           <li><img src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/Philips.png"), "html", null, true);
        echo "\" alt=\"\"></li>
           <li><img src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/Legrand.png"), "html", null, true);
        echo "\" alt=\"\"></li>
           <li><img src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/Chint.png"), "html", null, true);
        echo "\" alt=\"\"></li>
           <li><img src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/makita.png"), "html", null, true);
        echo "\" alt=\"\"></li>
       </ul>
       <div class=\"hero-area\">
           <div id=\"iview\">
           
           
                     <div  data-iview:image=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/maxresdefault.jpg"), "html", null, true);
        echo "\"  data-iview:transition=\"zigzag-drop-top,zigzag-drop-bottome\">
             
             <div class=\"iview-caption\" data-x=\"290\" data-y=\"214\" data-width=\"250\" data-height=\"200\" data-transition=\"fade\" data-speed=\"700\"><h1 class=\"philips\"><img src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/makita.png"), "html", null, true);
        echo "\" alt=\"\"></h1></div>
             
             <div class=\"iview-caption\" data-x=\"70\" data-y=\"50\" data-width=\"155\" data-height=\"220\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/pic1.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"230\" data-y=\"50\" data-width=\"155\" data-height=\"220\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/pic2.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"390\" data-y=\"50\" data-width=\"155\" data-height=\"220\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/pic3.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"550\" data-y=\"50\" data-width=\"155\" data-height=\"220\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/pic4.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             
    </div>           
                       
                 
                       
 <div  data-iview:image=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/maxresdefault.jpg"), "html", null, true);
        echo "\"  data-iview:transition=\"zigzag-drop-top,zigzag-drop-bottome\">
             
             <div class=\"iview-caption\" data-x=\"247\" data-y=\"241\" data-width=\"299\" data-height=\"261\" data-transition=\"fade\" data-speed=\"700\"><h1 class=\"philips\"><img src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/Chint.png"), "html", null, true);
        echo "\" alt=\"\"></h1></div>
             
             <div class=\"iview-caption\" data-x=\"100\" data-y=\"56\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/NB1.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"275\" data-y=\"56\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/eB.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"450\" data-y=\"56\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/NBH8.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             
             
             
    </div>
                                  
                                   
                                         
                                                     
                       
                       
                        <div  data-iview:image=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/maxresdefault.jpg"), "html", null, true);
        echo "\"  data-iview:transition=\"zigzag-drop-top,zigzag-drop-bottome\">
             
             <div class=\"iview-caption\" data-x=\"247\" data-y=\"241\" data-width=\"299\" data-height=\"261\" data-transition=\"fade\" data-speed=\"700\"><h1 class=\"philips\">DOMUS</h1></div>
             
             <div class=\"iview-caption\" data-x=\"100\" data-y=\"56\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/Domus1.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"275\" data-y=\"56\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/Domus2.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"450\" data-y=\"56\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/Domus3.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             
             
             
    </div>
           
         <div  data-iview:image=\"ressources/images/maxresdefault.jpg\"  data-iview:transition=\"zigzag-drop-top,zigzag-drop-bottome\">
             
             <div class=\"iview-caption\" data-x=\"247\" data-y=\"214\" data-width=\"250\" data-height=\"200\" data-transition=\"fade\" data-speed=\"700\"><h1 class=\"philips\">PHILIPS</h1></div>
             
             <div class=\"iview-caption\" data-x=\"70\" data-y=\"100\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"\"";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/5.5W%20MASTER%20LED.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"230\" data-y=\"100\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 76
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/ampoule-a-led-philips-master-ledspotmv-gu10-4-5w-2.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"390\" data-y=\"100\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/LEDspot%20PAR20.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             <div class=\"iview-caption\" data-x=\"550\" data-y=\"100\" data-width=\"150\" data-height=\"200\" data-transition=\"wipeRight\" data-speed=\"700\"><img src=\"";
        // line 80
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/philips-mled.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
             
             
    </div>
    
    
    

   

</div>

             
             
        
          
          
           
           <div class=\"services\">
               <ul>
                   <li><img class=\"shiping\" src=\"";
        // line 100
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/shiping.png"), "html", null, true);
        echo "\" alt=\"\"><span class=\"title ship-title\">LIVRAISON</span>
                   <p>Livraison GRATUITE en Tunisie</p>
                   
                   </li>
                   <li>
                   <span class=\"title map-title\">VISITEZ NOTRE BOUTIQUE</span>
                   <img src=\"";
        // line 106
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/map.png"), "html", null, true);
        echo "\" alt=\"\">
                   </li>
                   <li>
                   
                   <img src=\"\" alt=\"\">
                   <span class=\"title\">Nous Contacter</span>
                   <p>
            
                       Tél : 71 385 929 <br>
                       GSM: 98 248 408 <br>
                       Fax : 71 388 509 <br>
                  </p>
                  <span class=\"tel\"></span> 
                   </li>
               </ul>
           </div>
           </div>

       <h2></h2>
       <div style=\"clear:both;\"></div>
                  <div class=\"slogon\">
              <h2> <i class=\"fa fa-quote-left quote-left\"></i>&nbsp;&nbsp;&nbsp; Tout notre savoir-faire en matière de dépannage et d’installation électrique est mis à votre disposition pour la construction ou la rénovation de bâtiments. &nbsp;&nbsp;&nbsp; <i class=\"fa fa-quote-right quote-right\"></i></h2>
           </div>
       <div class=\"product-area\">
           <div class=\"box left-side\">
           
             <div class=\"title-block\">
                  <h3>CATÉGORIES</h3>
              </div>
              <ul>
                  <li><a href=\"\">Electricité industrielle </a></li>
                  <li><a href=\"\">Eclairage</a></li>
                  <li><a href=\"\">Mesure & controle</a></li>
                  <li><a href=\"\">Cablage éléctrique</a></li>
                  <li><a href=\"\">Electricité de batiments</a></li>
                  <li><a href=\"\">Fixation</a></li>
                  <li><a href=\"\">Divers</a></li>
                  <li><a href=\"\">Outillages</a></li>
              </ul>
             
           </div>
           <div class=\"main-content \">
             
             <div class=\"box products \">
                <div class=\"title-block \">
                     <h3>NOUVEAUX PRODUITS</h3>
                 </div>
                 <ul>
                     
                     
                   ";
        // line 156
        echo $this->env->getExtension('actions')->renderUri($this->env->getExtension('http_kernel')->controller("EcommerceEcommerceBundle:Default:newprod"), array());
        // line 157
        echo "               </ul>
             </div>             
  
                        <div class=\"box products\">
                <div class=\"title-block \">
                     <h3>TOP VENTES</h3>
                 </div>
        <ul>
        
        ";
        // line 166
        echo $this->env->getExtension('actions')->renderUri($this->env->getExtension('http_kernel')->controller("EcommerceEcommerceBundle:Default:topvente"), array());
        // line 167
        echo "           </ul>
                  </div>        
           </div>
           
       </div>
       
       <div style=\"clear:both;\"></div>
       <div class=\"footer-services\">
               <h2 class=\"center-lined \">Plus de raison pour magasiner chez euroelec</h2>
               <div class=\"col-1-of-4\">
                   <img src=\"";
        // line 177
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/price.png"), "html", null, true);
        echo "\" alt=\"\">
                   <span>Nous égalons les prix</span>
               </div>
               <div class=\"col-1-of-4\">
                   <img src=\"";
        // line 181
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/brands.png"), "html", null, true);
        echo "\" alt=\"\">
                   <span>Meilleures marques internationales</span>
               </div>
               <div class=\"col-1-of-4\">
                   <img src=\"";
        // line 185
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/free-shiping.png"), "html", null, true);
        echo "\" alt=\"\">
                   <span>Livraison rapide et gratuite</span>
               </div>
               <div class=\"col-1-of-4\">
                   <img src=\"";
        // line 189
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/quality.png"), "html", null, true);
        echo "\" alt=\"\">
                   <span>Grand choix de produits</span>
               </div>

       </div>
       <div style=\"clear:both;\"></div>
       <div class=\"footer-brands\">
               <h2 class=\"center-lined\">
                   Le choix des plus grandes marques
               </h2>
<div id=\"liquid1\" class=\"liquid\">
\t<span class=\"previous\"></span>
\t<div class=\"wrapper\">
\t\t<ul>
\t\t\t<li><a href=\"#\" title=\"image 01\"><img src=\"";
        // line 203
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/makita-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 01\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 01\"><img src=\"";
        // line 204
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/somef.png"), "html", null, true);
        echo "\" width=\"120\" height=\"50\" alt=\"image 01\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 02\"><img src=\"";
        // line 205
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/philips-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 02\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 03\"><img src=\"";
        // line 206
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/siemens-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 03\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 04\"><img src=\"";
        // line 207
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/varta-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 04\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 05\"><img src=\"";
        // line 208
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/shneider-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 05\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 06\"><img src=\"";
        // line 209
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/legrand-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 06\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 07\"><img src=\"";
        // line 210
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/chint-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 07\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 01\"><img src=\"";
        // line 211
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/makita-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 01\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 01\"><img src=\"";
        // line 212
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/somef1.png"), "html", null, true);
        echo "\" width=\"60\" height=\"60\" alt=\"image 01\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 02\"><img src=\"";
        // line 213
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/philips-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 02\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 03\"><img src=\"";
        // line 214
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/siemens-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 03\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 04\"><img src=\"";
        // line 215
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/varta-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 04\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 05\"><img src=\"";
        // line 216
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/shneider-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 05\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 06\"><img src=\"";
        // line 217
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/legrand-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 06\" border=\"0\" /></a></li>
\t\t\t<li><a href=\"#\" title=\"image 07\"><img src=\"";
        // line 218
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("ressources/images/chint-logo-slider.png"), "html", null, true);
        echo "\" width=\"88\" height=\"30\" alt=\"image 07\" border=\"0\" /></a></li>
\t\t\t
\t\t</ul>
\t</div>
\t<span class=\"next\"></span>
</div>
       </div>
   

   
";
    }

    public function getTemplateName()
    {
        return "EcommerceEcommerceBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  392 => 218,  388 => 217,  384 => 216,  380 => 215,  376 => 214,  372 => 213,  368 => 212,  364 => 211,  360 => 210,  356 => 209,  352 => 208,  348 => 207,  344 => 206,  340 => 205,  336 => 204,  332 => 203,  315 => 189,  308 => 185,  301 => 181,  294 => 177,  282 => 167,  280 => 166,  269 => 157,  267 => 156,  214 => 106,  205 => 100,  182 => 80,  177 => 78,  172 => 76,  167 => 74,  153 => 63,  148 => 61,  143 => 59,  136 => 55,  121 => 43,  116 => 41,  111 => 39,  106 => 37,  101 => 35,  91 => 28,  86 => 26,  81 => 24,  76 => 22,  71 => 20,  66 => 18,  57 => 12,  53 => 11,  49 => 10,  45 => 9,  41 => 8,  37 => 7,  31 => 3,  28 => 2,  11 => 1,);
    }
}
/* {%extends "EcommerceEcommerceBundle::layout.html.twig"%}*/
/* {% block content %}*/
/*     */
/*   */
/*         */
/*        <ul class="top-logos">*/
/*            <li><img src="{{asset('ressources/images/Siemens-logo.png')}}" alt=""></li>*/
/*            <li><img src="{{asset('ressources/images/shneider.png')}}" alt=""></li>*/
/*            <li><img src="{{asset('ressources/images/Philips.png')}}" alt=""></li>*/
/*            <li><img src="{{asset('ressources/images/Legrand.png')}}" alt=""></li>*/
/*            <li><img src="{{asset('ressources/images/Chint.png')}}" alt=""></li>*/
/*            <li><img src="{{asset('ressources/images/makita.png')}}" alt=""></li>*/
/*        </ul>*/
/*        <div class="hero-area">*/
/*            <div id="iview">*/
/*            */
/*            */
/*                      <div  data-iview:image="{{asset('ressources/images/maxresdefault.jpg')}}"  data-iview:transition="zigzag-drop-top,zigzag-drop-bottome">*/
/*              */
/*              <div class="iview-caption" data-x="290" data-y="214" data-width="250" data-height="200" data-transition="fade" data-speed="700"><h1 class="philips"><img src="{{asset('ressources/images/makita.png')}}" alt=""></h1></div>*/
/*              */
/*              <div class="iview-caption" data-x="70" data-y="50" data-width="155" data-height="220" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/pic1.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="230" data-y="50" data-width="155" data-height="220" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/pic2.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="390" data-y="50" data-width="155" data-height="220" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/pic3.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="550" data-y="50" data-width="155" data-height="220" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/pic4.jpg')}}" alt=""></div>*/
/*              */
/*              */
/*     </div>           */
/*                        */
/*                  */
/*                        */
/*  <div  data-iview:image="{{asset('ressources/images/maxresdefault.jpg')}}"  data-iview:transition="zigzag-drop-top,zigzag-drop-bottome">*/
/*              */
/*              <div class="iview-caption" data-x="247" data-y="241" data-width="299" data-height="261" data-transition="fade" data-speed="700"><h1 class="philips"><img src="{{asset('ressources/images/Chint.png')}}" alt=""></h1></div>*/
/*              */
/*              <div class="iview-caption" data-x="100" data-y="56" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/NB1.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="275" data-y="56" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/eB.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="450" data-y="56" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/NBH8.jpg')}}" alt=""></div>*/
/*              */
/*              */
/*              */
/*              */
/*     </div>*/
/*                                   */
/*                                    */
/*                                          */
/*                                                      */
/*                        */
/*                        */
/*                         <div  data-iview:image="{{asset('ressources/images/maxresdefault.jpg')}}"  data-iview:transition="zigzag-drop-top,zigzag-drop-bottome">*/
/*              */
/*              <div class="iview-caption" data-x="247" data-y="241" data-width="299" data-height="261" data-transition="fade" data-speed="700"><h1 class="philips">DOMUS</h1></div>*/
/*              */
/*              <div class="iview-caption" data-x="100" data-y="56" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/Domus1.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="275" data-y="56" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/Domus2.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="450" data-y="56" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/Domus3.jpg')}}" alt=""></div>*/
/*              */
/*              */
/*              */
/*              */
/*     </div>*/
/*            */
/*          <div  data-iview:image="ressources/images/maxresdefault.jpg"  data-iview:transition="zigzag-drop-top,zigzag-drop-bottome">*/
/*              */
/*              <div class="iview-caption" data-x="247" data-y="214" data-width="250" data-height="200" data-transition="fade" data-speed="700"><h1 class="philips">PHILIPS</h1></div>*/
/*              */
/*              <div class="iview-caption" data-x="70" data-y="100" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src=""{{asset('ressources/images/5.5W%20MASTER%20LED.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="230" data-y="100" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/ampoule-a-led-philips-master-ledspotmv-gu10-4-5w-2.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="390" data-y="100" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/LEDspot%20PAR20.jpg')}}" alt=""></div>*/
/*              */
/*              <div class="iview-caption" data-x="550" data-y="100" data-width="150" data-height="200" data-transition="wipeRight" data-speed="700"><img src="{{asset('ressources/images/philips-mled.jpg')}}" alt=""></div>*/
/*              */
/*              */
/*     </div>*/
/*     */
/*     */
/*     */
/* */
/*    */
/* */
/* </div>*/
/* */
/*              */
/*              */
/*         */
/*           */
/*           */
/*            */
/*            <div class="services">*/
/*                <ul>*/
/*                    <li><img class="shiping" src="{{asset('ressources/images/shiping.png')}}" alt=""><span class="title ship-title">LIVRAISON</span>*/
/*                    <p>Livraison GRATUITE en Tunisie</p>*/
/*                    */
/*                    </li>*/
/*                    <li>*/
/*                    <span class="title map-title">VISITEZ NOTRE BOUTIQUE</span>*/
/*                    <img src="{{asset('ressources/images/map.png')}}" alt="">*/
/*                    </li>*/
/*                    <li>*/
/*                    */
/*                    <img src="" alt="">*/
/*                    <span class="title">Nous Contacter</span>*/
/*                    <p>*/
/*             */
/*                        Tél : 71 385 929 <br>*/
/*                        GSM: 98 248 408 <br>*/
/*                        Fax : 71 388 509 <br>*/
/*                   </p>*/
/*                   <span class="tel"></span> */
/*                    </li>*/
/*                </ul>*/
/*            </div>*/
/*            </div>*/
/* */
/*        <h2></h2>*/
/*        <div style="clear:both;"></div>*/
/*                   <div class="slogon">*/
/*               <h2> <i class="fa fa-quote-left quote-left"></i>&nbsp;&nbsp;&nbsp; Tout notre savoir-faire en matière de dépannage et d’installation électrique est mis à votre disposition pour la construction ou la rénovation de bâtiments. &nbsp;&nbsp;&nbsp; <i class="fa fa-quote-right quote-right"></i></h2>*/
/*            </div>*/
/*        <div class="product-area">*/
/*            <div class="box left-side">*/
/*            */
/*              <div class="title-block">*/
/*                   <h3>CATÉGORIES</h3>*/
/*               </div>*/
/*               <ul>*/
/*                   <li><a href="">Electricité industrielle </a></li>*/
/*                   <li><a href="">Eclairage</a></li>*/
/*                   <li><a href="">Mesure & controle</a></li>*/
/*                   <li><a href="">Cablage éléctrique</a></li>*/
/*                   <li><a href="">Electricité de batiments</a></li>*/
/*                   <li><a href="">Fixation</a></li>*/
/*                   <li><a href="">Divers</a></li>*/
/*                   <li><a href="">Outillages</a></li>*/
/*               </ul>*/
/*              */
/*            </div>*/
/*            <div class="main-content ">*/
/*              */
/*              <div class="box products ">*/
/*                 <div class="title-block ">*/
/*                      <h3>NOUVEAUX PRODUITS</h3>*/
/*                  </div>*/
/*                  <ul>*/
/*                      */
/*                      */
/*                    {% render(controller('EcommerceEcommerceBundle:Default:newprod')) %}*/
/*                </ul>*/
/*              </div>             */
/*   */
/*                         <div class="box products">*/
/*                 <div class="title-block ">*/
/*                      <h3>TOP VENTES</h3>*/
/*                  </div>*/
/*         <ul>*/
/*         */
/*         {% render(controller('EcommerceEcommerceBundle:Default:topvente')) %}*/
/*            </ul>*/
/*                   </div>        */
/*            </div>*/
/*            */
/*        </div>*/
/*        */
/*        <div style="clear:both;"></div>*/
/*        <div class="footer-services">*/
/*                <h2 class="center-lined ">Plus de raison pour magasiner chez euroelec</h2>*/
/*                <div class="col-1-of-4">*/
/*                    <img src="{{asset('ressources/images/price.png')}}" alt="">*/
/*                    <span>Nous égalons les prix</span>*/
/*                </div>*/
/*                <div class="col-1-of-4">*/
/*                    <img src="{{asset('ressources/images/brands.png')}}" alt="">*/
/*                    <span>Meilleures marques internationales</span>*/
/*                </div>*/
/*                <div class="col-1-of-4">*/
/*                    <img src="{{asset('ressources/images/free-shiping.png')}}" alt="">*/
/*                    <span>Livraison rapide et gratuite</span>*/
/*                </div>*/
/*                <div class="col-1-of-4">*/
/*                    <img src="{{asset('ressources/images/quality.png')}}" alt="">*/
/*                    <span>Grand choix de produits</span>*/
/*                </div>*/
/* */
/*        </div>*/
/*        <div style="clear:both;"></div>*/
/*        <div class="footer-brands">*/
/*                <h2 class="center-lined">*/
/*                    Le choix des plus grandes marques*/
/*                </h2>*/
/* <div id="liquid1" class="liquid">*/
/* 	<span class="previous"></span>*/
/* 	<div class="wrapper">*/
/* 		<ul>*/
/* 			<li><a href="#" title="image 01"><img src="{{asset('ressources/images/makita-logo-slider.png')}}" width="88" height="30" alt="image 01" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 01"><img src="{{asset('ressources/images/somef.png')}}" width="120" height="50" alt="image 01" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 02"><img src="{{asset('ressources/images/philips-logo-slider.png')}}" width="88" height="30" alt="image 02" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 03"><img src="{{asset('ressources/images/siemens-logo-slider.png')}}" width="88" height="30" alt="image 03" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 04"><img src="{{asset('ressources/images/varta-logo-slider.png')}}" width="88" height="30" alt="image 04" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 05"><img src="{{asset('ressources/images/shneider-logo-slider.png')}}" width="88" height="30" alt="image 05" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 06"><img src="{{asset('ressources/images/legrand-logo-slider.png')}}" width="88" height="30" alt="image 06" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 07"><img src="{{asset('ressources/images/chint-logo-slider.png')}}" width="88" height="30" alt="image 07" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 01"><img src="{{asset('ressources/images/makita-logo-slider.png')}}" width="88" height="30" alt="image 01" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 01"><img src="{{asset('ressources/images/somef1.png')}}" width="60" height="60" alt="image 01" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 02"><img src="{{asset('ressources/images/philips-logo-slider.png')}}" width="88" height="30" alt="image 02" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 03"><img src="{{asset('ressources/images/siemens-logo-slider.png')}}" width="88" height="30" alt="image 03" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 04"><img src="{{asset('ressources/images/varta-logo-slider.png')}}" width="88" height="30" alt="image 04" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 05"><img src="{{asset('ressources/images/shneider-logo-slider.png')}}" width="88" height="30" alt="image 05" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 06"><img src="{{asset('ressources/images/legrand-logo-slider.png')}}" width="88" height="30" alt="image 06" border="0" /></a></li>*/
/* 			<li><a href="#" title="image 07"><img src="{{asset('ressources/images/chint-logo-slider.png')}}" width="88" height="30" alt="image 07" border="0" /></a></li>*/
/* 			*/
/* 		</ul>*/
/* 	</div>*/
/* 	<span class="next"></span>*/
/* </div>*/
/*        </div>*/
/*    */
/* */
/*    */
/* {% endblock %}*/
