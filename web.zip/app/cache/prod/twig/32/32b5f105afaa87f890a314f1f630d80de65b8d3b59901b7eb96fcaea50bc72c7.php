<?php

/* EcommerceEcommerceBundle:Default:one_prod_home.html.twig */
class __TwigTemplate_afac7d99416845594f9a60933955f2d6f92f4f573606d415886e8275aee6f494 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "             ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entities"]) ? $context["entities"] : $this->getContext($context, "entities")));
        foreach ($context['_seq'] as $context["_key"] => $context["entity"]) {
            // line 2
            echo "
<li>
                  <div class=\"product-img\">
                      <a href=\"\">
                         <img src=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl($this->getAttribute($this->getAttribute($context["entity"], "image", array()), "AssetPath", array())), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["entity"], "image", array()), "name", array()), "html", null, true);
            echo "\" width=\"100\" height=\"100\">
                          
                      </a>
                      
                     
                  </div>
                      <h4 class=\"libelle\">
                          <a href=\"#\">";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "nom", array()), "html", null, true);
            echo "</a>
                      </h4>
                      <h3 class=\"price\">";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "prix", array()), "html", null, true);
            echo "</h3>
                        
                    <div class=\"dbl-btn\">
                        <button class=\"voir\"><i class=\"fa fa-shopping-cart\"></i>
                            ";
            // line 19
            if (($this->getAttribute($context["entity"], "disponible", array()) == 1)) {
                // line 20
                echo "                          <strong >disponible</strong>
                        ";
            } else {
                // line 22
                echo "                            <strong  >hors stock</strong>
                        ";
            }
            // line 23
            echo "  
                        
                        
                        </button>
                    </div>    
                         
                         
                         
                         
                         
                     </li>
                     
                     
                      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entity'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "EcommerceEcommerceBundle:Default:one_prod_home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 23,  60 => 22,  56 => 20,  54 => 19,  47 => 15,  42 => 13,  30 => 6,  24 => 2,  19 => 1,);
    }
}
/*              {% for entity in entities %}*/
/* */
/* <li>*/
/*                   <div class="product-img">*/
/*                       <a href="">*/
/*                          <img src="{{ asset(entity.image.AssetPath) }}" alt="{{ entity.image.name }}" width="100" height="100">*/
/*                           */
/*                       </a>*/
/*                       */
/*                      */
/*                   </div>*/
/*                       <h4 class="libelle">*/
/*                           <a href="#">{{ entity.nom }}</a>*/
/*                       </h4>*/
/*                       <h3 class="price">{{ entity.prix }}</h3>*/
/*                         */
/*                     <div class="dbl-btn">*/
/*                         <button class="voir"><i class="fa fa-shopping-cart"></i>*/
/*                             {% if entity.disponible == 1 %}*/
/*                           <strong >disponible</strong>*/
/*                         {% else %}*/
/*                             <strong  >hors stock</strong>*/
/*                         {% endif %}  */
/*                         */
/*                         */
/*                         </button>*/
/*                     </div>    */
/*                          */
/*                          */
/*                          */
/*                          */
/*                          */
/*                      </li>*/
/*                      */
/*                      */
/*                       {% endfor %}*/
