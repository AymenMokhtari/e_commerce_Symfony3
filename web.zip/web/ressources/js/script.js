			$(document).ready(function(){
                     
				$('#iview').iView({
					pauseTime: 7000,
					pauseOnHover: true,
					directionNavHoverOpacity: 0,
					timer: "Bar",
					timerDiameter: "100%",
					timerPadding: 0,
					timerStroke: 7,
					timerBarStroke: 0,
					timerColor: "#FFF",
					timerPosition: "bottom-right"
				});
                

         
           
                
                
  });
		
                

    
    
    
    




                
                

