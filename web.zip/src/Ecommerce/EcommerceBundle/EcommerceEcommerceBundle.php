<?php

namespace Ecommerce\EcommerceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EcommerceEcommerceBundle extends Bundle
{

}
